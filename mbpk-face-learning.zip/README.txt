MBPK Face Learning (GitHub Pages)
1) Upload all files in this folder to your GitHub repo (root).
2) (Optional) Add your own files:
   - video_saya.mp4
   - eye.mp3, nose.mp3, mouth.mp3
   - correct.mp3, wrong.mp3
3) Settings > Pages > Deploy from main / root.
4) Open: https://USERNAME.github.io/REPO_NAME/
